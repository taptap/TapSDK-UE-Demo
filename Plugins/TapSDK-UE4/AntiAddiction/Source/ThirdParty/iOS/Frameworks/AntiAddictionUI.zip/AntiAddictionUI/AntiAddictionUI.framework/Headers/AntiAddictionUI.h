//
//  AntiAddictionUI.h
//  AntiAddictionUI
//
//  Created by jessy on 2021/9/17.
//

#import <Foundation/Foundation.h>

//! Project version number for AntiAddictionUI.
FOUNDATION_EXPORT double AntiAddictionUIVersionNumber;

//! Project version string for AntiAddictionUI.
FOUNDATION_EXPORT const unsigned char AntiAddictionUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AntiAddictionUI/PublicHeader.h>

#define AntiAddictionSDK_VERSION_NUMBER @"31804001"
#define AntiAddictionSDK_VERSION        @"3.18.4"

#import <AntiAddictionUI/AntiAddictionConfig.h>
#import <AntiAddictionUI/AntiAddiction.h>

